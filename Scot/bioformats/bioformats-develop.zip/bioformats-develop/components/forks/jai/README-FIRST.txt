The source code for the jai-imageio-core project is copyrighted code that
is licensed to individuals or companies who download or otherwise
access the code.

The copyright notice for this project is in COPYRIGHT.txt

The source code license for this project is in LICENSE.txt

Instructions for building this project are in README-build.html
